from django.db import models

# Create your models here.

class Icecream(models.Model):

    cone_wafer = models.CharField(max_length=100)
    base_flavour = models.CharField(max_length=100)
    toppings = models.CharField(max_length=100)
    address = models.CharField(max_length=100)
    contact_no = models.IntegerField()
    email = models.CharField(max_length=100)



class Orders(models.Model):

    cone_wafer = models.CharField(max_length=100)
    base_flavour = models.CharField(max_length=100)
    ROASTED_ALMONDS = 'roasted_almonds'
    TUTTI_FRUTI = 'tutti_fruti'
    CHOCOLATE_CHIPS = 'choco_chips'
    TOPPING_CHOICES = [
        (ROASTED_ALMONDS, 'Roasted Almonds'),
        (TUTTI_FRUTI, 'Tutti Fruti'),
        (CHOCOLATE_CHIPS, 'Chocolate Chips'),
    ]

    toppings = models.CharField(
        max_length=100,
        choices=TOPPING_CHOICES
    )
