from django.shortcuts import render,redirect
from django.http import HttpResponse
from .models import Icecream,Orders

# Create your views here.

def addToCart(request):

	if request.method == 'POST':

		cone_wafer = request.POST["wafer"]
		base_flavour = request.POST["flavour"]
		toppings = request.POST["toppings"]
	
		order = Orders.objects.create(cone_wafer=cone_wafer, base_flavour=base_flavour,
						toppings=toppings)
		order.save()
		return render(request,'addToCart.html')

	else: 
		return render(request,'/')

def viewCart(request):

	orders = Orders.objects.all
	return render(request,'viewCart.html',{'orders':orders})

def placeOrder(request):
	return render(request,'completeOrder.html')

def completeOrder(request):
		if request.method == 'POST':


			for item in Orders.objects.all():
				cone_wafer = item.cone_wafer
				base_flavour = item.base_flavour
				toppings = item.toppings
				address = request.POST["address"]
				contact_no = request.POST["contact_no"]
				email = request.POST["email"]

	
				icecream = Icecream.objects.create(cone_wafer=cone_wafer, base_flavour=base_flavour,
								toppings=toppings, address=address,contact_no=contact_no,email=email)
				icecream.save()
			return render(request,'index.html')

		else: 
			return render(request,'/')

def index(request):

	return render(request,'index.html')
